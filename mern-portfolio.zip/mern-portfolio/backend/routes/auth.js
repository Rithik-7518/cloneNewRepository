// routes/auth.js - Complete Authentication Routes
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const OTP = require('../models/OTP');
const jwt = require('jsonwebtoken');
const {
  generateOTP,
  sendOTPEmail,
  sendAdminNotification
} = require('../utils/emailService');

// ============================================
// @route   POST /api/auth/send-otp
// @desc    Send OTP to email (for both login and register)
// @access  Public
// ============================================
router.post('/send-otp', async (req, res) => {
  try {
    const { email } = req.body;

    // Validation
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    // Email format validation
    const emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format'
      });
    }

    // Check if user exists
    const existingUser = await User.findOne({ email: email.toLowerCase() });

    // Clean up old OTPs for this email
    await OTP.cleanupOldOTPs(email.toLowerCase());

    // Generate new OTP
    const otp = generateOTP();

    // Save OTP to database
    await OTP.create({
      email: email.toLowerCase(),
      otp: otp,
      type: existingUser ? 'login' : 'register'
    });

    // Send OTP via email
    const userName = existingUser ? existingUser.name : 'User';
    await sendOTPEmail(email, otp, userName);

    // Log for development
    console.log(`📧 OTP sent to ${email}: ${otp}`);

    res.json({
      success: true,
      message: 'OTP sent successfully to your email',
      userExists: !!existingUser,
      email: email.toLowerCase()
    });

  } catch (error) {
    console.error('Send OTP Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send OTP. Please try again.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// ============================================
// @route   POST /api/auth/verify-otp-login
// @desc    Verify OTP and login existing user
// @access  Public
// ============================================
router.post('/verify-otp-login', async (req, res) => {
  try {
    const { email, otp } = req.body;

    // Validation
    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Email and OTP are required'
      });
    }

    // Find valid OTP
    const otpRecord = await OTP.findValidOTP(email.toLowerCase(), otp);

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP'
      });
    }

    // Verify OTP
    const verificationResult = otpRecord.verifyOTP(otp);
    if (!verificationResult.success) {
      await otpRecord.save();
      return res.status(400).json({
        success: false,
        message: verificationResult.message
      });
    }

    // Save OTP as used
    await otpRecord.save();

    // Find user
    let user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      // Delete the used OTP
      await OTP.deleteOne({ _id: otpRecord._id });
      
      return res.status(400).json({
        success: false,
        message: 'User not found. Please register first.',
        needsRegistration: true
      });
    }

    // Update user verification and visit tracking
    user.isVerified = true;
    user.lastVisit = Date.now();
    user.visitCount += 1;
    await user.save();

    // Delete the used OTP
    await OTP.deleteOne({ _id: otpRecord._id });

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email,
        isAdmin: user.isAdmin
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Log successful login
    console.log(`✅ User logged in: ${user.email}`);

    res.json({
      success: true,
      message: 'Login successful!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin,
        visitCount: user.visitCount
      }
    });

  } catch (error) {
    console.error('Login Error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed. Please try again.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// ============================================
// @route   POST /api/auth/register
// @desc    Register new user with OTP verification
// @access  Public
// ============================================
router.post('/register', async (req, res) => {
  try {
    const { name, email, otp } = req.body;

    // Validation
    if (!name || !email || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and OTP are required'
      });
    }

    // Name validation
    if (name.trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Name must be at least 2 characters long'
      });
    }

    // Verify OTP
    const otpRecord = await OTP.findValidOTP(email.toLowerCase(), otp);

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP'
      });
    }

    // Check OTP verification
    const verificationResult = otpRecord.verifyOTP(otp);
    if (!verificationResult.success) {
      await otpRecord.save();
      return res.status(400).json({
        success: false,
        message: verificationResult.message
      });
    }

    // Save OTP as used
    await otpRecord.save();

    // Check if user already exists
    let user = await User.findOne({ email: email.toLowerCase() });

    if (user) {
      // Delete the used OTP
      await OTP.deleteOne({ _id: otpRecord._id });
      
      return res.status(400).json({
        success: false,
        message: 'User already exists. Please login instead.'
      });
    }

    // Create new user
    user = await User.create({
      name: name.trim(),
      email: email.toLowerCase(),
      isVerified: true,
      visitCount: 1
    });

    // Delete the used OTP
    await OTP.deleteOne({ _id: otpRecord._id });

    // Send notification to admin (don't block registration if this fails)
    try {
      await sendAdminNotification(user.name, user.email);
      console.log('📧 Admin notification sent for new user:', user.email);
    } catch (emailError) {
      console.error('⚠️  Failed to send admin notification:', emailError.message);
      // Continue with registration even if email fails
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email,
        isAdmin: user.isAdmin
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Log successful registration
    console.log(`✅ New user registered: ${user.email}`);

    res.status(201).json({
      success: true,
      message: 'Registration successful! Welcome!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin
      }
    });

  } catch (error) {
    console.error('Registration Error:', error);
    
    // Handle duplicate key error
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered. Please login.'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Registration failed. Please try again.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// ============================================
// @route   GET /api/auth/verify-token
// @desc    Verify if token is valid
// @access  Public (but requires token)
// ============================================
router.get('/verify-token', async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No token provided'
      });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Get user
    const user = await User.findById(decoded.userId).select('-__v');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'Token is valid',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin,
        visitCount: user.visitCount
      }
    });

  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token'
      });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token expired'
      });
    }
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
});

// ============================================
// @route   GET /api/auth/test
// @desc    Test route
// @access  Public
// ============================================
router.get('/test', (req, res) => {
  res.json({
    success: true,
    message: 'Auth routes are working!',
    availableRoutes: {
      sendOTP: 'POST /api/auth/send-otp',
      verifyLogin: 'POST /api/auth/verify-otp-login',
      register: 'POST /api/auth/register',
      verifyToken: 'GET /api/auth/verify-token'
    }
  });
});

module.exports = router;