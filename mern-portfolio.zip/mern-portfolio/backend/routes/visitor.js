// routes/visitor.js - Visitor Management Routes
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { verifyToken } = require('../middleware/auth');

// ============================================
// @route   GET /api/visitor/profile
// @desc    Get current user profile
// @access  Private
// ============================================
router.get('/profile', verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.userId)
      .select('-__v');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        isVerified: user.isVerified,
        isAdmin: user.isAdmin,
        visitCount: user.visitCount,
        lastVisit: user.lastVisit,
        registeredAt: user.registeredAt
      }
    });

  } catch (error) {
    console.error('Get Profile Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch profile'
    });
  }
});

// ============================================
// @route   POST /api/visitor/update-visit
// @desc    Update visit count for user
// @access  Private
// ============================================
router.post('/update-visit', verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Use the incrementVisit method we created in User model
    await user.incrementVisit();

    res.json({
      success: true,
      message: 'Visit count updated',
      visitCount: user.visitCount,
      lastVisit: user.lastVisit
    });

  } catch (error) {
    console.error('Update Visit Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update visit count'
    });
  }
});

// ============================================
// @route   PUT /api/visitor/update-profile
// @desc    Update user profile
// @access  Private
// ============================================
router.put('/update-profile', verifyToken, async (req, res) => {
  try {
    const { name, phoneNumber } = req.body;

    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update fields if provided
    if (name) user.name = name.trim();
    if (phoneNumber !== undefined) user.phoneNumber = phoneNumber;

    await user.save();

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber
      }
    });

  } catch (error) {
    console.error('Update Profile Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile'
    });
  }
});

// ============================================
// @route   GET /api/visitor/stats
// @desc    Get visitor's own statistics
// @access  Private
// ============================================
router.get('/stats', verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    const ResumeDownload = require('../models/ResumeDownload');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Get download count for this user
    const downloadCount = await ResumeDownload.countDocuments({ 
      userId: req.userId 
    });

    // Get last download
    const lastDownload = await ResumeDownload.findOne({ 
      userId: req.userId 
    }).sort({ downloadedAt: -1 });

    // Calculate days since registration
    const daysSinceRegistration = Math.floor(
      (Date.now() - user.registeredAt) / (1000 * 60 * 60 * 24)
    );

    res.json({
      success: true,
      stats: {
        visitCount: user.visitCount,
        downloadCount: downloadCount,
        daysSinceRegistration: daysSinceRegistration,
        lastVisit: user.lastVisit,
        lastDownload: lastDownload ? lastDownload.downloadedAt : null,
        memberSince: user.registeredAt
      }
    });

  } catch (error) {
    console.error('Get Stats Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch statistics'
    });
  }
});

// ============================================
// @route   GET /api/visitor/test
// @desc    Test visitor routes
// @access  Public
// ============================================
router.get('/test', (req, res) => {
  res.json({
    success: true,
    message: 'Visitor routes are working!',
    routes: {
      profile: 'GET /api/visitor/profile (protected)',
      updateVisit: 'POST /api/visitor/update-visit (protected)',
      updateProfile: 'PUT /api/visitor/update-profile (protected)',
      stats: 'GET /api/visitor/stats (protected)'
    }
  });
});

module.exports = router;