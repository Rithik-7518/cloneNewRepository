// routes/admin.js - Admin Dashboard Routes
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const ResumeDownload = require('../models/ResumeDownload');
const { verifyToken, verifyAdmin } = require('../middleware/auth');

// ============================================
// @route   GET /api/admin/dashboard
// @desc    Get admin dashboard statistics
// @access  Private (Admin only)
// ============================================
router.get('/dashboard', verifyToken, verifyAdmin, async (req, res) => {
  try {
    // Total visitors
    const totalVisitors = await User.countDocuments();

    // Verified users
    const verifiedUsers = await User.countDocuments({ isVerified: true });

    // Total visits (sum of all visitCount)
    const visitStats = await User.aggregate([
      {
        $group: {
          _id: null,
          totalVisits: { $sum: '$visitCount' }
        }
      }
    ]);

    // New users today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const newUsersToday = await User.countDocuments({
      registeredAt: { $gte: today }
    });

    // New users this week
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const newUsersThisWeek = await User.countDocuments({
      registeredAt: { $gte: weekAgo }
    });

    // New users this month
    const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const newUsersThisMonth = await User.countDocuments({
      registeredAt: { $gte: monthAgo }
    });

    // Total resume downloads
    const totalDownloads = await ResumeDownload.countDocuments();

    // Unique downloaders
    const uniqueDownloaders = await ResumeDownload.distinct('userId');

    // Downloads today
    const downloadsToday = await ResumeDownload.countDocuments({
      downloadedAt: { $gte: today }
    });

    // Recent visitors (last 10)
    const recentVisitors = await User.find()
      .sort({ lastVisit: -1 })
      .limit(10)
      .select('name email visitCount lastVisit registeredAt isAdmin');

    // Recent downloads (last 10)
    const recentDownloads = await ResumeDownload.find()
      .sort({ downloadedAt: -1 })
      .limit(10)
      .populate('userId', 'name email')
      .select('name email downloadedAt ipAddress device');

    res.json({
      success: true,
      stats: {
        visitors: {
          total: totalVisitors,
          verified: verifiedUsers,
          unverified: totalVisitors - verifiedUsers,
          newToday: newUsersToday,
          newThisWeek: newUsersThisWeek,
          newThisMonth: newUsersThisMonth
        },
        visits: {
          total: visitStats[0]?.totalVisits || 0,
          averagePerUser: totalVisitors > 0 
            ? (visitStats[0]?.totalVisits / totalVisitors).toFixed(2) 
            : 0
        },
        downloads: {
          total: totalDownloads,
          unique: uniqueDownloaders.length,
          today: downloadsToday,
          averagePerUser: totalVisitors > 0 
            ? (totalDownloads / totalVisitors).toFixed(2) 
            : 0
        }
      },
      recentActivity: {
        visitors: recentVisitors,
        downloads: recentDownloads
      }
    });

  } catch (error) {
    console.error('Dashboard Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard data'
    });
  }
});

// ============================================
// @route   GET /api/admin/visitors
// @desc    Get all visitors with pagination
// @access  Private (Admin only)
// ============================================
router.get('/visitors', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    // Filters
    const filter = {};
    if (req.query.verified === 'true') filter.isVerified = true;
    if (req.query.verified === 'false') filter.isVerified = false;

    // Sorting
    const sortBy = req.query.sortBy || 'registeredAt';
    const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;
    const sort = { [sortBy]: sortOrder };

    // Get visitors
    const visitors = await User.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .select('name email visitCount lastVisit registeredAt isVerified isAdmin');

    // Total count
    const total = await User.countDocuments(filter);

    res.json({
      success: true,
      visitors,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
        hasMore: page * limit < total
      }
    });

  } catch (error) {
    console.error('Get Visitors Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch visitors'
    });
  }
});

// ============================================
// @route   GET /api/admin/downloads
// @desc    Get all resume downloads with pagination
// @access  Private (Admin only)
// ============================================
router.get('/downloads', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    // Filters
    const filter = {};
    if (req.query.email) {
      filter.email = { $regex: req.query.email, $options: 'i' };
    }

    // Get downloads
    const downloads = await ResumeDownload.find(filter)
      .sort({ downloadedAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('userId', 'name email visitCount');

    // Total count
    const total = await ResumeDownload.countDocuments(filter);

    res.json({
      success: true,
      downloads,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
        hasMore: page * limit < total
      }
    });

  } catch (error) {
    console.error('Get Downloads Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch downloads'
    });
  }
});

// ============================================
// @route   GET /api/admin/visitor/:id
// @desc    Get single visitor details
// @access  Private (Admin only)
// ============================================
router.get('/visitor/:id', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Visitor not found'
      });
    }

    // Get download history for this user
    const downloads = await ResumeDownload.find({ userId: user._id })
      .sort({ downloadedAt: -1 });

    res.json({
      success: true,
      visitor: user,
      downloads: downloads
    });

  } catch (error) {
    console.error('Get Visitor Details Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch visitor details'
    });
  }
});

// ============================================
// @route   GET /api/admin/analytics
// @desc    Get detailed analytics
// @access  Private (Admin only)
// ============================================
router.get('/analytics', verifyToken, verifyAdmin, async (req, res) => {
  try {
    // Get registration trend (last 7 days)
    const registrationTrend = await User.aggregate([
      {
        $match: {
          registeredAt: {
            $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$registeredAt' }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    // Get download trend (last 7 days)
    const downloadTrend = await ResumeDownload.aggregate([
      {
        $match: {
          downloadedAt: {
            $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$downloadedAt' }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    // Top visitors by visit count
    const topVisitors = await User.find()
      .sort({ visitCount: -1 })
      .limit(5)
      .select('name email visitCount');

    res.json({
      success: true,
      analytics: {
        registrationTrend,
        downloadTrend,
        topVisitors
      }
    });

  } catch (error) {
    console.error('Get Analytics Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch analytics'
    });
  }
});

// ============================================
// @route   GET /api/admin/test
// @desc    Test admin routes
// @access  Public
// ============================================
router.get('/test', (req, res) => {
  res.json({
    success: true,
    message: 'Admin routes are working!',
    routes: {
      dashboard: 'GET /api/admin/dashboard (admin only)',
      visitors: 'GET /api/admin/visitors (admin only)',
      downloads: 'GET /api/admin/downloads (admin only)',
      visitorDetails: 'GET /api/admin/visitor/:id (admin only)',
      analytics: 'GET /api/admin/analytics (admin only)'
    }
  });
});

module.exports = router;