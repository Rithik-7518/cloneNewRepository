// routes/test.js - Testing our models
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const OTP = require('../models/OTP');
const ResumeDownload = require('../models/ResumeDownload');

// Test: Create a sample user
router.post('/create-user', async (req, res) => {
  try {
    const user = await User.create({
      name: 'Test User',
      email: 'test@example.com',
      isVerified: true
    });

    res.json({
      success: true,
      message: 'User created successfully!',
      data: user
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    
    res.json({
      success: true,
      count: users.length,
      data: users
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Create OTP
router.post('/create-otp', async (req, res) => {
  try {
    // Clean up old OTPs for this email
    await OTP.cleanupOldOTPs('test@example.com');

    // Create new OTP
    const otp = await OTP.create({
      email: 'test@example.com',
      otp: '123456',
      type: 'login'
    });

    res.json({
      success: true,
      message: 'OTP created successfully!',
      data: otp,
      expiresIn: '5 minutes'
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Verify OTP
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    
    const otpRecord = await OTP.findValidOTP(email, otp);
    
    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP'
      });
    }

    const result = otpRecord.verifyOTP(otp);
    await otpRecord.save();

    res.json({
      success: result.success,
      message: result.message,
      data: otpRecord
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Create resume download record
router.post('/create-download', async (req, res) => {
  try {
    // First, get a user
    let user = await User.findOne({ email: 'test@example.com' });
    
    if (!user) {
      // Create user if doesn't exist
      user = await User.create({
        name: 'Test User',
        email: 'test@example.com',
        isVerified: true
      });
    }

    // Create download record
    const download = await ResumeDownload.create({
      userId: user._id,
      name: user.name,
      email: user.email,
      ipAddress: req.ip || '127.0.0.1',
      userAgent: req.get('user-agent'),
      device: {
        type: 'desktop',
        browser: 'Chrome',
        os: 'Windows'
      }
    });

    res.json({
      success: true,
      message: 'Download recorded successfully!',
      data: download
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Get all downloads with user details
router.get('/downloads', async (req, res) => {
  try {
    const downloads = await ResumeDownload.find()
      .populate('userId', 'name email visitCount')
      .sort({ downloadedAt: -1 });
    
    res.json({
      success: true,
      count: downloads.length,
      data: downloads
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Increment user visit
router.post('/increment-visit/:email', async (req, res) => {
  try {
    const user = await User.findOne({ email: req.params.email });
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    await user.incrementVisit();

    res.json({
      success: true,
      message: 'Visit incremented!',
      data: {
        email: user.email,
        visitCount: user.visitCount,
        lastVisit: user.lastVisit
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Get statistics
router.get('/stats', async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const verifiedUsers = await User.countDocuments({ isVerified: true });
    const totalDownloads = await ResumeDownload.getTotalDownloads();
    const uniqueDownloaders = await ResumeDownload.getUniqueDownloaders();

    res.json({
      success: true,
      data: {
        totalUsers,
        verifiedUsers,
        unverifiedUsers: totalUsers - verifiedUsers,
        totalDownloads,
        uniqueDownloaders: uniqueDownloaders.length,
        averageDownloadsPerUser: totalUsers > 0 ? (totalDownloads / totalUsers).toFixed(2) : 0
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Delete all test data
router.delete('/cleanup', async (req, res) => {
  try {
    await User.deleteMany({ email: 'test@example.com' });
    await OTP.deleteMany({ email: 'test@example.com' });
    await ResumeDownload.deleteMany({ email: 'test@example.com' });

    res.json({
      success: true,
      message: 'All test data cleaned up!'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

router.post('/create-admin', async (req, res) => {
  try {
    const { name, email } = req.body;
    
    // Check if user exists
    let user = await User.findOne({ email: email.toLowerCase() });
    
    if (user) {
      // Make existing user admin
      user.isAdmin = true;
      await user.save();
      
      return res.json({
        success: true,
        message: 'User is now an admin!',
        user: {
          name: user.name,
          email: user.email,
          isAdmin: user.isAdmin
        }
      });
    }
    
    // Create new admin user
    user = await User.create({
      name,
      email: email.toLowerCase(),
      isAdmin: true,
      isVerified: true,
      visitCount: 0
    });
    
    res.json({
      success: true,
      message: 'Admin user created!',
      user: {
        name: user.name,
        email: user.email,
        isAdmin: user.isAdmin
      }
    });
    
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

module.exports = router;