// routes/resume.js - Resume Download Routes
const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const User = require('../models/User');
const ResumeDownload = require('../models/ResumeDownload');
const { verifyToken } = require('../middleware/auth');
const { sendDownloadNotification } = require('../utils/emailService');

// ============================================
// @route   GET /api/resume/info
// @desc    Get resume information
// @access  Public
// ============================================
router.get('/info', (req, res) => {
  try {
    const resumePath = path.join(__dirname, '../public/resume');
    const files = fs.readdirSync(resumePath);
    const pdfFiles = files.filter(file => file.endsWith('.pdf'));

    if (pdfFiles.length === 0) {
      return res.json({
        success: true,
        available: false,
        message: 'Resume not available yet'
      });
    }

    const resumeFile = pdfFiles[0];
    const stats = fs.statSync(path.join(resumePath, resumeFile));

    res.json({
      success: true,
      available: true,
      fileName: resumeFile,
      fileSize: stats.size,
      fileSizeFormatted: (stats.size / 1024).toFixed(2) + ' KB',
      lastModified: stats.mtime
    });

  } catch (error) {
    res.json({
      success: true,
      available: false,
      message: 'Resume not available yet'
    });
  }
});

// ============================================
// @route   POST /api/resume/download
// @desc    Download resume and track it
// @access  Private
// ============================================
router.post('/download', verifyToken, async (req, res) => {
  try {
    // Get user details
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Get IP address
    const ipAddress = req.ip || 
                     req.headers['x-forwarded-for'] || 
                     req.connection.remoteAddress;

    // Get user agent
    const userAgent = req.get('user-agent') || 'Unknown';

    // Detect device type
    let deviceType = 'desktop';
    if (/mobile/i.test(userAgent)) deviceType = 'mobile';
    else if (/tablet/i.test(userAgent)) deviceType = 'tablet';

    // Extract browser and OS (simple detection)
    let browser = 'Unknown';
    let os = 'Unknown';
    
    if (userAgent.includes('Chrome')) browser = 'Chrome';
    else if (userAgent.includes('Firefox')) browser = 'Firefox';
    else if (userAgent.includes('Safari')) browser = 'Safari';
    else if (userAgent.includes('Edge')) browser = 'Edge';
    
    if (userAgent.includes('Windows')) os = 'Windows';
    else if (userAgent.includes('Mac')) os = 'MacOS';
    else if (userAgent.includes('Linux')) os = 'Linux';
    else if (userAgent.includes('Android')) os = 'Android';
    else if (userAgent.includes('iOS')) os = 'iOS';

    // Path to resume file
    const resumePath = path.join(__dirname, '../public/resume');
    const files = fs.readdirSync(resumePath);
    const pdfFiles = files.filter(file => file.endsWith('.pdf'));

    if (pdfFiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Resume file not found'
      });
    }

    const resumeFile = pdfFiles[0];
    const fullPath = path.join(resumePath, resumeFile);
    const stats = fs.statSync(fullPath);

    // Record download in database
    const download = await ResumeDownload.create({
      userId: user._id,
      name: user.name,
      email: user.email,
      ipAddress: ipAddress,
      userAgent: userAgent,
      device: {
        type: deviceType,
        browser: browser,
        os: os
      },
      fileVersion: '1.0',
      fileSize: stats.size,
      status: 'completed'
    });

    // Send notification to admin (don't block download if this fails)
    try {
      await sendDownloadNotification(user.name, user.email);
      console.log('📧 Download notification sent to admin');
    } catch (emailError) {
      console.error('⚠️  Failed to send download notification:', emailError.message);
    }

    // Log download
    console.log(`📄 Resume downloaded by: ${user.email}`);

    // Send file
    res.download(fullPath, resumeFile, (err) => {
      if (err) {
        console.error('Download Error:', err);
        // Update status to failed
        download.status = 'failed';
        download.save();
      }
    });

  } catch (error) {
    console.error('Resume Download Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to download resume'
    });
  }
});

// ============================================
// @route   GET /api/resume/my-downloads
// @desc    Get current user's download history
// @access  Private
// ============================================
router.get('/my-downloads', verifyToken, async (req, res) => {
  try {
    const downloads = await ResumeDownload.find({ userId: req.userId })
      .sort({ downloadedAt: -1 })
      .select('-__v');

    const count = downloads.length;

    res.json({
      success: true,
      count,
      downloads
    });

  } catch (error) {
    console.error('Get Downloads Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch download history'
    });
  }
});

// ============================================
// @route   GET /api/resume/test
// @desc    Test resume routes
// @access  Public
// ============================================
router.get('/test', (req, res) => {
  res.json({
    success: true,
    message: 'Resume routes are working!',
    routes: {
      info: 'GET /api/resume/info (public)',
      download: 'POST /api/resume/download (protected)',
      myDownloads: 'GET /api/resume/my-downloads (protected)'
    }
  });
});

module.exports = router;