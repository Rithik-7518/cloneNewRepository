// routes/emailTest.js
const express = require('express');
const router = express.Router();
const {
  generateOTP,
  sendOTPEmail,
  sendAdminNotification,
  sendDownloadNotification
} = require('../utils/emailService');

// Test: Generate OTP
router.get('/generate-otp', (req, res) => {
  try {
    const otp = generateOTP();
    res.json({
      success: true,
      message: 'OTP generated successfully',
      otp: otp,
      note: 'In production, OTP should never be returned in API response'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Send OTP Email
router.post('/send-otp', async (req, res) => {
  try {
    const { email, name } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    const otp = generateOTP();
    const result = await sendOTPEmail(email, otp, name || 'User');

    res.json({
      success: true,
      message: 'OTP email sent successfully!',
      email: email,
      otp: otp,  // Remove this in production!
      messageId: result.messageId
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Send Admin Notification
router.post('/send-admin-notification', async (req, res) => {
  try {
    const { name, email } = req.body;

    if (!name || !email) {
      return res.status(400).json({
        success: false,
        message: 'Name and email are required'
      });
    }

    const result = await sendAdminNotification(name, email);

    res.json({
      success: true,
      message: 'Admin notification sent successfully!',
      result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Send Download Notification
router.post('/send-download-notification', async (req, res) => {
  try {
    const { name, email } = req.body;

    if (!name || !email) {
      return res.status(400).json({
        success: false,
        message: 'Name and email are required'
      });
    }

    const result = await sendDownloadNotification(name, email);

    res.json({
      success: true,
      message: 'Download notification sent successfully!',
      result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Test: Send test email to yourself
router.get('/send-test-email', async (req, res) => {
  try {
    const otp = generateOTP();
    await sendOTPEmail(process.env.EMAIL_USER, otp, 'Test User');

    res.json({
      success: true,
      message: 'Test email sent to ' + process.env.EMAIL_USER,
      otp: otp
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

module.exports = router;