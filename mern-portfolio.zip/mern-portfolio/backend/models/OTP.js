// models/OTP.js
const mongoose = require('mongoose');

const OTPSchema = new mongoose.Schema({
  // Email for OTP
  email: {
    type: String,
    required: [true, 'Email is required'],
    lowercase: true,
    trim: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Please provide a valid email'
    ]
  },

  // OTP Code
  otp: {
    type: String,
    required: [true, 'OTP is required'],
    length: 6
  },

  // OTP Type
  type: {
    type: String,
    enum: ['login', 'register', 'password-reset'],
    default: 'login'
  },

  // Attempt tracking
  attempts: {
    type: Number,
    default: 0,
    max: 5  // Maximum 5 attempts
  },

  // Used status
  isUsed: {
    type: Boolean,
    default: false
  },

  // IP Address (optional security feature)
  ipAddress: {
    type: String,
    default: null
  },

  // User Agent (optional security feature)
  userAgent: {
    type: String,
    default: null
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 300  // Document will be automatically deleted after 5 minutes (300 seconds)
  },

  usedAt: {
    type: Date,
    default: null
  }

}, {
  timestamps: false  // We're handling createdAt manually
});

// Indexes
OTPSchema.index({ email: 1 });
OTPSchema.index({ createdAt: 1 }, { expireAfterSeconds: 0 });

// Instance method - verify OTP
OTPSchema.methods.verifyOTP = function(inputOTP) {
  if (this.isUsed) {
    return { success: false, message: 'OTP already used' };
  }
  
  if (this.attempts >= 5) {
    return { success: false, message: 'Maximum attempts exceeded' };
  }

  this.attempts += 1;

  if (this.otp === inputOTP) {
    this.isUsed = true;
    this.usedAt = Date.now();
    return { success: true, message: 'OTP verified successfully' };
  }

  return { 
    success: false, 
    message: `Invalid OTP. ${5 - this.attempts} attempts remaining` 
  };
};

// Static method - find valid OTP for email
OTPSchema.statics.findValidOTP = async function(email, otp) {
  return await this.findOne({
    email,
    otp,
    isUsed: false,
    attempts: { $lt: 5 }
  });
};

// Static method - clean up old OTPs for email
OTPSchema.statics.cleanupOldOTPs = async function(email) {
  return await this.deleteMany({ email });
};

module.exports = mongoose.model('OTP', OTPSchema);