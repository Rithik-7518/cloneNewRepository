// models/User.js
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  // Basic Information
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    minlength: [2, 'Name must be at least 2 characters'],
    maxlength: [50, 'Name cannot exceed 50 characters']
  },
  
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Please provide a valid email'
    ]
  },

  // Verification Status
  isVerified: {
    type: Boolean,
    default: false
  },

  // User Role
  isAdmin: {
    type: Boolean,
    default: false
  },

  // Visit Tracking
  visitCount: {
    type: Number,
    default: 0,
    min: 0
  },

  lastVisit: {
    type: Date,
    default: Date.now
  },

  // Registration
  registeredAt: {
    type: Date,
    default: Date.now
  },

  // Additional Info (optional)
  phoneNumber: {
    type: String,
    default: null
  },

  location: {
    city: String,
    country: String
  },

  // User preferences
  preferences: {
    emailNotifications: {
      type: Boolean,
      default: true
    },
    theme: {
      type: String,
      enum: ['light', 'dark'],
      default: 'light'
    }
  }

}, {
  timestamps: true  // Automatically adds createdAt and updatedAt
});

// Indexes for faster queries
UserSchema.index({ email: 1 });
UserSchema.index({ registeredAt: -1 });
UserSchema.index({ lastVisit: -1 });

// Virtual field - full name with email
UserSchema.virtual('displayName').get(function() {
  return `${this.name} (${this.email})`;
});

// Instance method - increment visit count
UserSchema.methods.incrementVisit = async function() {
  this.visitCount += 1;
  this.lastVisit = Date.now();
  return await this.save();
};

// Static method - find active users (visited in last 30 days)
UserSchema.statics.findActiveUsers = function() {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  return this.find({ 
    lastVisit: { $gte: thirtyDaysAgo } 
  }).sort({ lastVisit: -1 });
};

// Pre-save middleware - runs before saving
UserSchema.pre('save', function(next) {
  // You can add custom logic here
  console.log(`Saving user: ${this.email}`);
  next();
});

module.exports = mongoose.model('User', UserSchema);