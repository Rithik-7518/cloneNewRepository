// models/ResumeDownload.js
const mongoose = require('mongoose');

const ResumeDownloadSchema = new mongoose.Schema({
  // User Reference
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',  // Reference to User model
    required: [true, 'User ID is required']
  },

  // User Details (denormalized for faster queries)
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true
  },

  email: {
    type: String,
    required: [true, 'Email is required'],
    lowercase: true,
    trim: true
  },

  // Download Information
  downloadedAt: {
    type: Date,
    default: Date.now
  },

  // Request Details
  ipAddress: {
    type: String,
    default: null
  },

  userAgent: {
    type: String,
    default: null
  },

  // Device Information
  device: {
    type: {
      type: String,
      enum: ['desktop', 'mobile', 'tablet', 'unknown'],
      default: 'unknown'
    },
    browser: String,
    os: String
  },

  // Location (if you implement geo-location)
  location: {
    city: String,
    region: String,
    country: String,
    coordinates: {
      lat: Number,
      lng: Number
    }
  },

  // File Information
  fileVersion: {
    type: String,
    default: '1.0'
  },

  fileSize: {
    type: Number,  // in bytes
    default: 0
  },

  // Download Status
  status: {
    type: String,
    enum: ['initiated', 'completed', 'failed'],
    default: 'completed'
  },

  // Referrer (where user came from)
  referrer: {
    type: String,
    default: null
  }

}, {
  timestamps: true  // Adds createdAt and updatedAt
});

// Indexes for faster queries
ResumeDownloadSchema.index({ userId: 1 });
ResumeDownloadSchema.index({ email: 1 });
ResumeDownloadSchema.index({ downloadedAt: -1 });
ResumeDownloadSchema.index({ status: 1 });

// Virtual - time since download
ResumeDownloadSchema.virtual('timeSinceDownload').get(function() {
  const now = new Date();
  const diff = now - this.downloadedAt;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days} day(s) ago`;
  if (hours > 0) return `${hours} hour(s) ago`;
  if (minutes > 0) return `${minutes} minute(s) ago`;
  return 'Just now';
});

// Static method - get download count for user
ResumeDownloadSchema.statics.getDownloadCountByUser = async function(userId) {
  return await this.countDocuments({ userId });
};

// Static method - get downloads for date range
ResumeDownloadSchema.statics.getDownloadsByDateRange = async function(startDate, endDate) {
  return await this.find({
    downloadedAt: {
      $gte: startDate,
      $lte: endDate
    }
  }).populate('userId', 'name email');
};

// Static method - get total downloads
ResumeDownloadSchema.statics.getTotalDownloads = async function() {
  return await this.countDocuments();
};

// Static method - get unique downloaders
ResumeDownloadSchema.statics.getUniqueDownloaders = async function() {
  return await this.distinct('userId');
};

module.exports = mongoose.model('ResumeDownload', ResumeDownloadSchema);