// middleware/auth.js
const jwt = require('jsonwebtoken');

// Verify user token
const verifyToken = async (req, res, next) => {
  try {
    // Get token from header
    const token = req.header('Authorization');
    
    if (!token) {
      return res.status(401).json({ 
        success: false,
        message: 'Access denied. No token provided.' 
      });
    }

    // Remove 'Bearer ' prefix if exists
    const actualToken = token.startsWith('Bearer ') 
      ? token.slice(7) 
      : token;

    // Verify token
    const decoded = jwt.verify(actualToken, process.env.JWT_SECRET);
    
    // Add user info to request
    req.userId = decoded.userId;
    req.userEmail = decoded.email;
    req.isAdmin = decoded.isAdmin || false;
    
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ 
        success: false,
        message: 'Invalid token' 
      });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        success: false,
        message: 'Token expired' 
      });
    }
    res.status(500).json({ 
      success: false,
      message: 'Server error' 
    });
  }
};

// Verify admin access
const verifyAdmin = async (req, res, next) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).json({ 
        success: false,
        message: 'Access denied. Admin only.' 
      });
    }
    next();
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Server error' 
    });
  }
};

module.exports = { verifyToken, verifyAdmin };