// utils/emailService.js
const nodemailer = require('nodemailer');

// Create reusable transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  },
  // Additional options for better reliability
  pool: true,
  maxConnections: 5,
  maxMessages: 100,
  rateDelta: 1000,
  rateLimit: 5
});

// Verify transporter configuration
transporter.verify((error, success) => {
  if (error) {
    console.error('❌ Email Service Error:', error.message);
  } else {
    console.log('✅ Email Service is ready to send emails');
  }
});

// Generate 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// OTP Email Template
const getOTPEmailTemplate = (otp, userName = 'User') => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
        }
        .container {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 30px;
          border-radius: 10px;
          text-align: center;
        }
        .content {
          background: white;
          padding: 30px;
          border-radius: 8px;
          margin-top: 20px;
        }
        .otp-box {
          background: #f7f7f7;
          border: 2px dashed #667eea;
          padding: 20px;
          margin: 20px 0;
          border-radius: 8px;
        }
        .otp-code {
          font-size: 32px;
          font-weight: bold;
          color: #667eea;
          letter-spacing: 5px;
          margin: 10px 0;
        }
        .footer {
          margin-top: 20px;
          font-size: 12px;
          color: #666;
        }
        .warning {
          background: #fff3cd;
          border-left: 4px solid #ffc107;
          padding: 10px;
          margin: 15px 0;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1 style="color: white; margin: 0;">Portfolio Verification</h1>
      </div>
      <div class="content">
        <h2>Hello ${userName}!</h2>
        <p>Thank you for visiting my portfolio. To complete your verification, please use the OTP below:</p>
        
        <div class="otp-box">
          <p style="margin: 0; font-size: 14px; color: #666;">Your One-Time Password</p>
          <div class="otp-code">${otp}</div>
          <p style="margin: 0; font-size: 12px; color: #999;">Valid for 5 minutes</p>
        </div>

        <div class="warning">
          <strong>⚠️ Security Notice:</strong>
          <p style="margin: 5px 0;">Never share this OTP with anyone. We will never ask for your OTP via phone or email.</p>
        </div>

        <p>If you didn't request this OTP, please ignore this email.</p>
        
        <div class="footer">
          <p>This is an automated email. Please do not reply.</p>
          <p>&copy; 2025 Portfolio. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
};

// Admin Notification Template
const getAdminNotificationTemplate = (userName, userEmail, timestamp) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
        }
        .container {
          background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
          padding: 30px;
          border-radius: 10px;
          text-align: center;
        }
        .content {
          background: white;
          padding: 30px;
          border-radius: 8px;
          margin-top: 20px;
        }
        .info-box {
          background: #f8f9fa;
          border-left: 4px solid #f5576c;
          padding: 15px;
          margin: 20px 0;
        }
        .info-row {
          display: flex;
          justify-content: space-between;
          padding: 10px 0;
          border-bottom: 1px solid #eee;
        }
        .label {
          font-weight: bold;
          color: #666;
        }
        .value {
          color: #333;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1 style="color: white; margin: 0;">🎉 New User Registration</h1>
      </div>
      <div class="content">
        <h2>New visitor registered on your portfolio!</h2>
        <p>You have a new registered user. Here are their details:</p>
        
        <div class="info-box">
          <div class="info-row">
            <span class="label">Name:</span>
            <span class="value">${userName}</span>
          </div>
          <div class="info-row">
            <span class="label">Email:</span>
            <span class="value">${userEmail}</span>
          </div>
          <div class="info-row">
            <span class="label">Registration Time:</span>
            <span class="value">${timestamp}</span>
          </div>
        </div>

        <p>This user has successfully verified their email and can now access your portfolio content.</p>
        
        <p style="margin-top: 30px; font-size: 14px; color: #666;">
          You can view detailed analytics in your admin dashboard.
        </p>
      </div>
    </body>
    </html>
  `;
};

// Resume Download Notification Template
const getDownloadNotificationTemplate = (userName, userEmail, timestamp) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
        }
        .container {
          background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
          padding: 30px;
          border-radius: 10px;
          text-align: center;
        }
        .content {
          background: white;
          padding: 30px;
          border-radius: 8px;
          margin-top: 20px;
        }
        .info-box {
          background: #f8f9fa;
          border-left: 4px solid #4facfe;
          padding: 15px;
          margin: 20px 0;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1 style="color: white; margin: 0;">📄 Resume Downloaded</h1>
      </div>
      <div class="content">
        <h2>Your resume was downloaded!</h2>
        <div class="info-box">
          <p><strong>Downloaded by:</strong> ${userName}</p>
          <p><strong>Email:</strong> ${userEmail}</p>
          <p><strong>Time:</strong> ${timestamp}</p>
        </div>
      </div>
    </body>
    </html>
  `;
};

// Send OTP Email
const sendOTPEmail = async (email, otp, userName = 'User') => {
  try {
    const mailOptions = {
      from: {
        name: 'Portfolio Verification',
        address: process.env.EMAIL_USER
      },
      to: email,
      subject: `Your OTP: ${otp} - Portfolio Verification`,
      html: getOTPEmailTemplate(otp, userName),
      // Text version for email clients that don't support HTML
      text: `Hello ${userName},\n\nYour OTP for portfolio verification is: ${otp}\n\nThis OTP will expire in 5 minutes.\n\nIf you didn't request this, please ignore this email.`
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ OTP Email sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Error sending OTP email:', error.message);
    throw new Error('Failed to send OTP email');
  }
};

// Send Admin Notification
const sendAdminNotification = async (userName, userEmail) => {
  try {
    const timestamp = new Date().toLocaleString('en-US', {
      dateStyle: 'full',
      timeStyle: 'long'
    });

    const mailOptions = {
      from: {
        name: 'Portfolio System',
        address: process.env.EMAIL_USER
      },
      to: process.env.ADMIN_EMAIL,
      subject: `🎉 New User Registration - ${userName}`,
      html: getAdminNotificationTemplate(userName, userEmail, timestamp),
      text: `New user registered!\n\nName: ${userName}\nEmail: ${userEmail}\nTime: ${timestamp}`
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Admin notification sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Error sending admin notification:', error.message);
    // Don't throw error - admin notification failure shouldn't block registration
    return { success: false, error: error.message };
  }
};

// Send Download Notification
const sendDownloadNotification = async (userName, userEmail) => {
  try {
    const timestamp = new Date().toLocaleString('en-US', {
      dateStyle: 'full',
      timeStyle: 'long'
    });

    const mailOptions = {
      from: {
        name: 'Portfolio System',
        address: process.env.EMAIL_USER
      },
      to: process.env.ADMIN_EMAIL,
      subject: `📄 Resume Downloaded - ${userName}`,
      html: getDownloadNotificationTemplate(userName, userEmail, timestamp),
      text: `Resume downloaded!\n\nBy: ${userName}\nEmail: ${userEmail}\nTime: ${timestamp}`
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Download notification sent:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Error sending download notification:', error.message);
    return { success: false, error: error.message };
  }
};

module.exports = {
  generateOTP,
  sendOTPEmail,
  sendAdminNotification,
  sendDownloadNotification,
  transporter
};