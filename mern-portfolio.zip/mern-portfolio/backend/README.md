# Portfolio Backend API

## Description
Backend server for MERN stack portfolio website with OTP authentication, admin dashboard, and resume download tracking.

## Tech Stack
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **JWT** - Authentication
- **Nodemailer** - Email service

## Installation

```bash
# Install dependencies
npm install

# Create .env file and add your configuration
cp .env.example .env
```

## Environment Variables

Create a `.env` file with the following:

```
PORT=5000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret_key
EMAIL_USER=your_email@gmail.com
EMAIL_PASSWORD=your_app_password
ADMIN_EMAIL=admin@example.com
FRONTEND_URL=http://localhost:3000
```

## Running the Server

```bash
# Development mode with auto-restart
npm run dev

# Production mode
npm start
```

## API Endpoints

### Authentication
- `POST /api/auth/send-otp` - Send OTP to email
- `POST /api/auth/verify-otp-login` - Verify OTP and login
- `POST /api/auth/register` - Register new user

### Admin
- `GET /api/admin/dashboard` - Get dashboard statistics
- `GET /api/admin/visitors` - Get all visitors

### Resume
- `POST /api/resume/download` - Download resume (authenticated)

## Project Structure

```
backend/
├── models/          # Database models
├── routes/          # API routes
├── middleware/      # Custom middleware
├── utils/           # Utility functions
├── public/          # Static files
│   └── resume/      # Resume PDFs
├── .env             # Environment variables
├── .gitignore       # Git ignore file
├── server.js        # Main server file
└── package.json     # Dependencies
```

## Features
- ✅ OTP-based authentication
- ✅ Email notifications
- ✅ Admin dashboard with analytics
- ✅ Resume download tracking
- ✅ Visit counting
- ✅ JWT token-based sessions

## Development Progress
- [x] Day 1: Initial setup
- [ ] Day 2: Backend foundation
- [ ] Day 3: Database models
- [ ] Day 4: Email configuration
- [ ] Day 5-7: API routes

## Author
Your Name

## License
MIT