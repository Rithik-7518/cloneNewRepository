// src/pages/Education.js
import React from 'react';

const Education = () => {
  return (
    <div className="page-container">
      <h1>Education</h1>
      <p>My educational background</p>
    </div>
  );
};

export default Education;