// src/pages/Resume.js
import React from 'react';

const Resume = () => {
  return (
    <div className="page-container">
      <h1>Resume</h1>
      <p>Download my resume</p>
    </div>
  );
};

export default Resume;