// src/pages/About.js
import React from 'react';

const About = () => {
  return (
    <div className="page-container">
      <h1>About Page</h1>
      <p>Learn more about me</p>
    </div>
  );
};

export default About;