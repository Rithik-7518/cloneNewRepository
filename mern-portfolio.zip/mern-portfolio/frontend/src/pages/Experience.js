// src/pages/Experience.js
import React from 'react';

const Experience = () => {
  return (
    <div className="page-container">
      <h1>Work Experience</h1>
      <p>My professional experience</p>
    </div>
  );
};

export default Experience;