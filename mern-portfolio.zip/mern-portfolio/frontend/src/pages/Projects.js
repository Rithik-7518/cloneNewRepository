// src/pages/Projects.js
import React from 'react';

const Projects = () => {
  return (
    <div className="page-container">
      <h1>Projects</h1>
      <p>Projects I've worked on</p>
    </div>
  );
};

export default Projects;