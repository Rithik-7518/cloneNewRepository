// src/pages/Home.js
import React from 'react';

const Home = () => {
  return (
    <div className="page-container">
      <h1>Home Page</h1>
      <p>Welcome to my portfolio!</p>
    </div>
  );
};

export default Home;