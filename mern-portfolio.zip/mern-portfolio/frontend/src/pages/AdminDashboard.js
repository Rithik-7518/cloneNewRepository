// src/pages/AdminDashboard.js
import React from 'react';

const AdminDashboard = () => {
  return (
    <div className="page-container">
      <h1>Admin Dashboard</h1>
      <p>Analytics and statistics</p>
    </div>
  );
};

export default AdminDashboard;