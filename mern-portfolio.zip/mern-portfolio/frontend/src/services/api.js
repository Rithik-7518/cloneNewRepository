// src/services/api.js
import axios from 'axios';

// Base URL for API
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds
});

// Request interceptor - Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - Handle errors globally
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response) {
      // Server responded with error
      const { status, data } = error.response;
      
      if (status === 401) {
        // Unauthorized - clear token and redirect to login
        localStorage.removeItem('token');
        window.location.href = '/';
      }
      
      console.error('API Error:', data.message || 'Something went wrong');
    } else if (error.request) {
      // Request made but no response
      console.error('Network Error:', 'No response from server');
    } else {
      // Something else happened
      console.error('Error:', error.message);
    }
    
    return Promise.reject(error);
  }
);

// ============================================
// Authentication APIs
// ============================================

export const authAPI = {
  // Send OTP
  sendOTP: (email) => api.post('/auth/send-otp', { email }),
  
  // Verify OTP and login
  login: (email, otp) => api.post('/auth/verify-otp-login', { email, otp }),
  
  // Register new user
  register: (name, email, otp) => api.post('/auth/register', { name, email, otp }),
  
  // Verify token
  verifyToken: () => api.get('/auth/verify-token'),
};

// ============================================
// Visitor APIs
// ============================================

export const visitorAPI = {
  // Get profile
  getProfile: () => api.get('/visitor/profile'),
  
  // Update visit count
  updateVisit: () => api.post('/visitor/update-visit'),
  
  // Update profile
  updateProfile: (data) => api.put('/visitor/update-profile', data),
  
  // Get stats
  getStats: () => api.get('/visitor/stats'),
};

// ============================================
// Resume APIs
// ============================================

export const resumeAPI = {
  // Get resume info
  getInfo: () => api.get('/resume/info'),
  
  // Download resume
  download: () => api.post('/resume/download', {}, { responseType: 'blob' }),
  
  // Get my downloads
  getMyDownloads: () => api.get('/resume/my-downloads'),
};

// ============================================
// Admin APIs
// ============================================

export const adminAPI = {
  // Get dashboard
  getDashboard: () => api.get('/admin/dashboard'),
  
  // Get visitors
  getVisitors: (params) => api.get('/admin/visitors', { params }),
  
  // Get downloads
  getDownloads: (params) => api.get('/admin/downloads', { params }),
  
  // Get visitor details
  getVisitorDetails: (id) => api.get(`/admin/visitor/${id}`),
  
  // Get analytics
  getAnalytics: () => api.get('/admin/analytics'),
};

export default api;