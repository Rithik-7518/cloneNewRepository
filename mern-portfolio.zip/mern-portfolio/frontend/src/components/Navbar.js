// src/components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          Portfolio
        </Link>

        <ul className="navbar-menu">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/education">Education</Link></li>
          <li><Link to="/experience">Experience</Link></li>
          <li><Link to="/projects">Projects</Link></li>
          <li><Link to="/resume">Resume</Link></li>
          
          {isAuthenticated && user?.isAdmin && (
            <li><Link to="/admin">Admin</Link></li>
          )}
        </ul>

        <div className="navbar-auth">
          {isAuthenticated ? (
            <>
              <span className="user-name">Hi, {user?.name}!</span>
              <button onClick={logout} className="btn-logout">
                Logout
              </button>
            </>
          ) : (
            <span className="auth-status">Guest</span>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;